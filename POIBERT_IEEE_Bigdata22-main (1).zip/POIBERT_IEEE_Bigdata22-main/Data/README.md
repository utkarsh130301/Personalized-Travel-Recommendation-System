## Data files 
* please download the Flickr User-POI Visits Dataset [https://sites.google.com/site/limkwanhui/datacode] in this directory.
